package net.roarsoftware.lastfm;

/**
 * @author Janni Kovacs
 */
public enum ImageSize {

	SMALL,
	MEDIUM,
	LARGE,
	LARGESQUARE,
	HUGE,
	EXTRALARGE,
	ORIGINAL

}
